//var urlSito='http://www.anomalie.piccoloweb.net';
var urlSito = 'http://localhost/web_anomalie2';

//var snd = new Audio("sound.mp3"); // buffers automatically when created
/*
if (!window.indexedDB) {
    alert("Il tuo browser non supporta indexedDB");
}else{
    alert("Il tuo browser SUPPORTA indexedDB");
}
*/
if(navigator.onLine){
 console.log('We are connected!');
} else {
 console.log('We do not have connectivity.');
}








//***************************************************************************
//        YDN-DB
//****************************************************************************/

//      FX: CREA DATABASE 
// ---------------------------------
// TODO: creare schema per dati utente e url del server base e del Comune scelto
// TODO: recupera la versione di stradario e tipologie new_versione_configurazione

var dbs, schema;
// drop_db();
schema = {
    version:2,
    stores: [{
        name: 'stradario',    // required. object store name or TABLE name
        keyPath: 'strada',    // keyPath.
        autoIncrement: false, // if true, key will be automatically created
        indexes: [{
            keyPath: 'strada', // required.
            unique: true,      // unique constrain
        multiEntry: true   //
        }]
    }, {
        name: 'tipologie',
        keyPath: 'tipo',
        indexes: [{
            keyPath: 'tipo', // required.
            unique: true,      // unique constrain
        multiEntry: true   //
        }]
    }, {
        name: 'configurazione',
        keyPath: 'id'
    }]
};

dbs = new ydn.db.Storage('db-name', schema);


// ----------------------------
// FX: aggiorna_store_stradario 
// ----------------------------

function aggiorna_store_stradario(dati){
    
    var objs = dati;   
    dbs.clear('stradario');
    dbs.put('stradario',objs);
};


// -----------------------------
// FX: aggiorna_store_tipologie 
// ----------------------------
    
function aggiorna_store_tipologie(dati){
    
    var objs = dati;
    dbs.clear('tipologie');
    dbs.put('tipologie',objs);
};



// -----------------------------
// FX: DROP DATABASE 
// -----------------------------
// fx di test

function drop_db(){
    ydn.db.deleteDatabase('db-name');
}


// -----------------------------
// FX: REGISTRA VALORE 
// -----------------------------
// registra_valore('configurazione', 1, 'idUtente', 20, fx_callback);


function registra_valore(store, keypath, oggetto, callback){
    
    req = dbs.put({name: store, keyPath: 'id'}, oggetto);
    req.done(function(key) {
      callback(key);
    });
    req.fail(function(e) {
      throw e;
    });    
}


// -----------------------------
// FX: ESTRAI CONFIGURAZIONE > RECORD
// -----------------------------

function estrai_configurazione(callback){
    
    req = dbs.get('configurazione', 1);
    req.done(function(record) {
        console.log('estrai_configurazione .122 ok -> ' + callback.name);
        callback(record);
    });
    req.fail(function(e) {
      console.log('errore: ' + e.message);
    });    
}


// ------------------------------------------------------------------------------------------
//      FX: raccoglie gli eventi tap e li gira alla fx azione
// ------------------------------------------------------------------------------------------

document.on('tap', function (el) {

    var dati = el.target.id;
    var datiDivisi = dati.split('_');
    var azione = datiDivisi[0];
    var idRecord = datiDivisi[1];
    cattura_tap(azione, idRecord);
    //console.log(azione + idRecord);
});

document.on('submit', function (el) {
    //snd.play();
    console.log('submit!');
    el.preventDefault();
});






// -----------------------------------
//      FX: cattura_tap - sceglie tra tutti i tap quelli che corrispondono alle azioni configurate
// -----------------------------------


function cattura_tap(az, id) {
    
    var converti = {
        
        iscrizione: 1, edit: 2, cancItem: 3, cancellaDb: 4, aggiorna: 5
    };
    var azione;
    azione = converti[az];
    if (!azione) {
        
        azione = 'azione non ancora configurata'
    }
    console.log('azione [azione]: ' + azione + ' sul [record]: ' + id);
    
    switch (azione) {
            
    case 1:
            
        iscriviti();
        // A nomeUtente, email > S idUtente > A
            
    break;
    case 2:
        break;
    case 3:
        break;
    case 4:
            
        drop_db();
    
    break;
    case 5:
            
        recupera_stradario_dal_web();
        recupera_tipologie_dal_web();
        // cancella i dati in db e li ricarica dal server
        // TODO: fx che confronta la versione S con quella nella A, se S>A segnala la necessità di un aggiornamento.
        
    break;
    default:
        console.log('x');
        break;

    }
}




// ------------------------------
//      FX: FRAMEWORK PHONON
// ------------------------------

phonon.options({
    navigator: {
        defaultPage: 'home', 
        hashPrefix: '!', // default !pagename
        animatePages: true, 
        enableBrowserBackButton: true, 
        templateRootDirectory: 'tpl/', 
        useHash: true // true to enable hash routing, false otherwise
    },
    i18n: null //if you do not want to use internationalization    }
});
var app = phonon.navigator();
app.on({
    page: 'home', 
    content: 'home.html'
},
    function (activity) {
        activity.onTransitionEnd(function () {
            estrai_configurazione(inizializza_home);
        }),
        activity.onReady(function () {
            estrai_configurazione(inizializza_home);
        });
    });

app.on({
    page: 'segnala',
    content: 'segnala.html'
},
    function (activity) {
        activity.onTransitionEnd(function () {
            inizializza_segnala();
   
            
            
            
var video = document.getElementById('video');

// Get access to the camera!
if(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    // Not adding `{ audio: true }` since we only want video now
    navigator.mediaDevices.getUserMedia({ video: true }).then(function(stream) {
        video.src = window.URL.createObjectURL(stream);
        video.play();
    });
}            
            
            
var canvas = document.getElementById('canvas');
var context = canvas.getContext('2d');
var video = document.getElementById('video');

// Trigger photo take
document.getElementById("scatta_foto").addEventListener("click", function() {
	context.drawImage(video, 0, 0, 100, 100 * video.height / video.width);
    convertCanvasToImage(context, html_img)
});        
    
            
            
function convertCanvasToImage(canvas, callback) {
  var image = new Image();
  image.onload = function(){
    html_img(image);
  }
  canvas = document.getElementById("canvas");
  image.src = canvas.toDataURL("image/png");
        
}            
            
            
   function html_img(image){
    document.getElementById('foto').style.backgroundImage = 'url(' + image.src + ')';
//       sessionStorage.setItem("img_api",image);
  //      document.getElementById('foto').setAttribute('src','data:image/jpeg;base64,' + image.src);
       
   }         
            
   
document.getElementById("downloader").addEventListener("click", function() {
    document.getElementById("downloader").download = "imageaaaa.png";
    document.getElementById("downloader").href = document.getElementById("canvas").toDataURL("image/png").replace(/^data:image\/[^;]/, 'data:application/octet-stream');
}  );      
               
            
            
            

        });
    });

app.on({
    page: 'settings',
    content: 'settings.html'
},
    function (activity) {
        activity.onTransitionEnd(function () {
        });
    });

app.on({
    page: 'iscrizione',
    content: 'iscrizione.html' 
},
    function (activity) {
    
        activity.onTransitionEnd(function () {            
        });
    });

app.on({
    page: 'credit',
    content: 'credit.html'
});

app.on({
    page: 'archivio',
    content: 'archivio.html'
},
    function (activity) {
    activity.onCreate(function () {
        var els = document.getElementsByClassName("dragEnd");
        Array.prototype.forEach.call(els, function (el) {
            var a = new Dragend(el, {
                onDragEnd: function () {
                    // inserire qui le azioni da compiere al termine del
                    //trascinamento degli elementi dell'archivio
                    //alert(el.id);
                }
            });
        });
    });
});


// ------------------------------------
//      FX: CONTROLLA ISCRIZIONE
// ------------------------------------

function controlla_iscrizione(record){
    if(!record){
        console.log('controlla_iscrizione: negativo');
        phonon.navigator().changePage('iscrizione');         
        }
    else{
        //callback(record);            
    }  
}


app.start();
estrai_configurazione(controlla_iscrizione);
//estrai_configurazione(inizializza_home);


// ---------------------------------------- 
//      FX: INIZIALIZZA HOME
// ----------------------------------------

function inizializza_home(record){
    
    idUtente = record['idUtente'];
    nomeUtente = record['nomeUtente'];
    document.getElementById('nomeUtente').innerHTML = nomeUtente + '.' + idUtente;
}



// ---------------------------------------- 
//      FX: INIZIALIZZA segnala
// ----------------------------------------

function inizializza_segnala(){    
    var myhtml_stradario = '';
    var myhtml_tipologie = '';
    var q = dbs.values('stradario');
    q.done(function(myArray){
        myArray.forEach(function (item, i) {
            myhtml_stradario += '<option value="' + item['strada'] + '" >' + item['strada'] + '</option>\n\r';
        });
        //console.log(myhtml_stradario);
        document.getElementById('select_stradario').innerHTML = myhtml_stradario;
    });
    
    var q = dbs.values('tipologie');
    q.done(function(myArray){
        myArray.forEach(function (item, i) {
            myhtml_tipologie += '<option value="' + item['tipo'] + '" >' + item['tipo'] + '</option>\n\r';
        });
        //console.log(myhtml_stradario);
        document.getElementById('select_tipologie').innerHTML = myhtml_tipologie;
    });
    
    
    
    //document.getElementById('nomeUtente').innerHTML = nomeUtente + '.' + idUtente;
}


function IMPLEMENTAREscrivi_select_stradario(myArray) {
    
    var myhtml = '';
    var myArray = myArray;
    myArray.forEach(function (item, i) {
        myhtml += '<option value="' + item + '" >' + item + '</option>\n\r';
    });
    console.log(myhtml);
}





// ---------------------------------------- 
//      FX: AGGIORNA STRADARIO e TIPOLOGIE
// ----------------------------------------


function recupera_tipologie_dal_web() {

    var richiesta = urlSito + '/web_fornisci_dati.php?operazione=new_tipologie';
    recupera_tabella_dal_web(richiesta, aggiorna_store_tipologie);
}

function recupera_stradario_dal_web() {
    
    var richiesta = urlSito + '/web_fornisci_dati.php?operazione=new_stradario';
    recupera_tabella_dal_web(richiesta, aggiorna_store_stradario);
}




// -------------------------------------------------------------------------------------- 
//      FX: iscrizione 
// --------------------------------------------------------------------------------------
// A nome, mail > S idUtente > A
// A idUtente > DB 
// carica Home

function iscriviti(){

    nomeUtente=document.form_iscrizione.nomeUtente.value;
    email= document.form_iscrizione.email.value;
    var richiesta = urlSito + '/web_fornisci_dati.php?operazione=new_iscrizione&nomeUtente='+ nomeUtente +'&email=' + email;
    console.log('ok 2:' + richiesta);
    invia_richiesta(richiesta, aggiorna_store_configurazione);    
}

function aggiorna_store_configurazione(r){
    nomeUtente=document.form_iscrizione.nomeUtente.value;
    email= document.form_iscrizione.email.value;
    
    var oggetto = {'id':1, idUtente: r['idUtente'], nomeUtente: nomeUtente, email: email }
    
    document.form_iscrizione.reset();//document.getElementById("myForm").reset()
    //nomeUtente=document.form_iscrizione.nomeUtente.value;
    //email= document.form_iscrizione.email.value;
    registra_valore('configurazione', 1, oggetto, pagina_home);
}

function pagina_home(){
    
    phonon.navigator().changePage('home');
}




// ------------------------------
// FX: recupera dati dal web
// ------------------------------

function recupera_tabella_dal_web(richiesta, callback) {
    
    var xmlhttp;
    var r = richiesta;
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    }
    else {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            
            var dati = xmlhttp.responseText;
            
            var myArr = JSON.parse(xmlhttp.responseText);
            callback(myArr);
        }
    };
    xmlhttp.open("POST", r, true);
    xmlhttp.send();
}




// ------------------------------
// FX: registrati sul server
// ------------------------------

function invia_richiesta(richiesta, callback) {

    console.log(richiesta);
    var xmlhttp;
    var r = richiesta;
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    }
    else {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            
            var dati = xmlhttp.responseText;
            
            var myArr = JSON.parse(xmlhttp.responseText);
            callback(myArr);
        }
    };
    xmlhttp.open("POST", r, true);
    xmlhttp.send();
}





//********************************************************************************************






/*
function scrivi_select_stradario(myArray) {
    
    var myhtml = '';
    var myArray = myArray;
    myArray.forEach(function (item, i) {
        myhtml += '<option value="' + item + '" >' + item + '</option>\n\r';
    });
    console.log(myhtml);
}



function elenca_le_tabelle(){
    html += '<li ><button id="cancDb_' + d + '" class="btn negative"><i class="icon i-cancella" ></i> ' + d + '</button></li>';
    
}
// ------------------------------------------------- 
// ELIMINATA   elenca paesi disponibili
// -------------------------------------------------
/*

function recupera_paesi_disponibili_dal_web() {
    
    var richiesta = urlSito + '/app_base.php?paese=fornisci_paesi_disponibili';
    recupera_tabella_dal_web(richiesta, scrivi_option);
}


function scrivi_option(myArray) {
    
    var myhtml = '';
    var myArray = myArray;
    myArray.forEach(function (item, i) {
        myhtml += '<option value="' + item + '" >' + item + '</option>\n\r';
    });
    document.getElementById('select_paesi').innerHTML += myhtml;
    //console.log('FX: scrivi_option: '+ myhtml);
}








*/


