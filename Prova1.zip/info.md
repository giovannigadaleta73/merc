APP COMUNiCA
============

A operazione=**new_stradario** > S > Array stradario

A operazione=**new_tipologie** > S > Array tipologie
